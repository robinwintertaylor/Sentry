# Sentry

A Windows security watch agent for Buzz. Reads logs hourly, explains what it finds in plain English, proposes a response for you to approve, and writes a monthly hardening report.

**It never acts on its own.** Sentry reads. You decide. You act.

---

## Start here

| Document | For |
|---|---|
| **[WHAT-IS-SENTRY.md](WHAT-IS-SENTRY.md)** | What it does, what it deliberately can't do, and whether it's right for you |
| **[DEPLOY-SENTRY.md](DEPLOY-SENTRY.md)** | Installation, end to end, about twenty minutes |

---

## What's in the box

```
sentry.agent.json          import this into Buzz (My Agents -> Import)
sentry.agent.png           same thing, PNG-wrapped
sentry-1.0.0.buzzpack      CLI install path: buzz install
sentry-1.0.0.zip           identical, opens in any zip tool

sentry/
  agents/sentry.persona.md the agent's full instructions
  scripts/                 9 PowerShell scripts, all read-only
  avatars/                 two styles, work and home
  instructions.md          operating rules
```

## The nine scripts

| Script | Runs | Returns |
|---|---|---|
| `Get-SecuritySnapshot.ps1` | hourly | AV product and health (any vendor), firewall, exclusions, log tampering |
| `Get-ProcessActivity.ps1` | hourly | Process creations with command lines, parents, signatures |
| `Get-ScriptActivity.ps1` | hourly | PowerShell script blocks, decoded base64, obfuscation scoring |
| `Get-PersistenceCheck.ps1` | hourly | Autostart inventory, diffed against the previous run |
| `Get-NetworkActivity.ps1` | hourly | Connections by process, listening ports, DNS |
| `Get-HardeningPosture.ps1` | monthly | ~60 configuration settings, plus how the machine is used |
| `Invoke-SentryCollection.ps1` | hourly | Wrapper the scheduler runs |
| `Invoke-SentryMonthly.ps1` | monthly | Wrapper the scheduler runs |
| `Register-SentryTask.ps1` | once | Setup: logging, permissions, both tasks |

Every one is read-only. None of them change a setting, and the agent cannot write its own.

## Requirements

Windows 10 or 11 you administer · a Buzz relay · a model provider key · ~2 GB disk

Works alongside any antivirus — it reads the Windows Security Center, which every vendor registers with. It complements your AV rather than replacing it.

## The two things people get wrong

**Skipping the logging setup.** Windows doesn't record process command lines by default. Without them, most detection is guesswork. `Register-SentryTask.ps1` handles it; run it as Administrator.

**Leaving Goose's developer extension on.** It includes a general shell, and this is the one agent where that default is wrong. An agent that watches for malicious PowerShell while able to run PowerShell is a contradiction. Turn it off — see DEPLOY step 6.
